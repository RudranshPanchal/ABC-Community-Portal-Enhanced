package com.example.demo.service;

import com.example.demo.beans.Apply;

public interface ApplyService {
	public void addApply (Apply a);
	
}
